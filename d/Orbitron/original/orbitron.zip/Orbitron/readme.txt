Thank you for downloading Orbitron, a font by Matt McInerney.

This font is subject to the Open Font License.

This font was intended for display purposes only.

I recommend that you use the OTF version of Orbitron. The TTF version is provided for software incompatible with OTF. EOT files are provided for use in Internet Explorer.

You may use this font freely on the web with @font-face, SIFR, Cufon, etc.

If you encounter any problems with Orbitron feel free to email me at matt@pixelspread.com

Any updates to this font will be posted on http://theleagueofmoveabletype.com

To see more of my work visit http://pixelspread.com